namespace CSharpGyakorloFeladatsor;

/// <summary>
/// A gyakorló feladatsor megoldandó metódusai.
/// A metódusok törzse szándékosan nincs elkészítve.
/// A megoldásoknak a példákon túl a szélső esetekre is helyes eredményt kell adniuk.
/// </summary>
public static class Feladatok
{
    // =========================
    // KÖNNYŰ FELADATOK
    // =========================

    /// <summary>
    /// 1. feladat – Kisbetűk száma
    /// Add vissza, hány kisbetű található a megadott szövegben!
    /// Példa: "Almafa12" -> 5.
    /// Gondolj az üres szövegre és arra az esetre is, amikor nincs kisbetű.
    /// </summary>
    public static int KisbetukSzama(string szoveg)
    {
        return -1;
    }

    /// <summary>
    /// 2. feladat – Legnagyobb számjegy
    /// Add vissza egy nemnegatív egész szám legnagyobb számjegyét!
    /// Példa: 583204 -> 8.
    /// A 0 esetén az eredmény 0.
    /// Gondolj az egyjegyű, sokjegyű és nullát tartalmazó számokra is.
    /// </summary>
    public static int LegnagyobbSzamjegy(int szam)
    {
        return -1;
    }

    /// <summary>
    /// 3. feladat – Páros számok összege
    /// Add össze a tömbben található páros számokat, és add vissza az összeget!
    /// Ha nincs páros szám, az eredmény 0.
    /// Példa: [5, 8, -2, 7, 4] -> 10.
    /// Gondolj az üres tömbre, a páros szám nélküli és a csak páros számokat tartalmazó tömbre is.
    /// </summary>
    public static int ParosSzamokOsszege(int[] szamok)
    {
        return -1;
    }

    /// <summary>
    /// 4. feladat – Utolsó negatív szám értéke
    /// Add vissza a tömbben található utolsó negatív szám értékét!
    /// Ha nincs negatív szám, adj vissza 0-t!
    /// Példa: [4, -7, 8, -3, 5] -> -3.
    /// Fontos: nem az elem indexét, hanem magát a negatív értéket kell visszaadni.
    /// </summary>
    public static int UtolsoNegativErtek(int[] szamok)
    {
        return 0;
    }

    /// <summary>
    /// 5. feladat – Átlag alatti elemek száma
    /// Számítsd ki a tömb elemeinek átlagát, majd add vissza,
    /// hány elem kisebb szigorúan az átlagnál!
    /// Példa: [10, 20, 30, 40] -> 2, mert az átlag 25.
    /// Gondolj az egy elemű és az azonos értékeket tartalmazó tömbre is.
    /// </summary>
    public static int AtlagAlattiDarab(int[] szamok)
    {
        return -1;
    }

    // =========================
    // KÖZEPES FELADATOK
    // =========================

    /// <summary>
    /// 6. feladat – Jelszó alapellenőrzése
    /// Egy jelszó akkor érvényes, ha legalább 8 karakter hosszú,
    /// tartalmaz legalább egy nagybetűt, egy kisbetűt és egy számjegyet.
    /// Példa: "Almafa25" -> true, "almafa25" -> false.
    /// </summary>
    public static bool ErvenyesJelszo(string jelszo)
    {
        return false;
    }

    /// <summary>
    /// 7. feladat – Első átlag feletti dolgozó
    /// A dolgozók neve és pontszáma azonos indexen összetartozik.
    /// Számítsd ki a pontszámok átlagát, majd add vissza az első olyan dolgozó nevét,
    /// akinek pontszáma szigorúan nagyobb az átlagnál!
    /// Példa: ["Anna", "Bela", "Csilla", "David"], [60, 70, 95, 75] -> "Csilla".
    /// A példában az átlag 75.
    /// Gondolj arra, hogy az első átlag feletti dolgozó lehet a tömb elején, közepén vagy végén.
    /// </summary>
    public static string ElsoAtlagFelettiDolgozo(string[] nevek, int[] pontok)
    {
        return "NINCS_MEGOLDVA";
    }

    /// <summary>
    /// 8. feladat – Számjegygyakoriság
    /// Készíts egy 10 elemű tömböt, amely megadja, hogy a 0–9 számjegyek
    /// hányszor fordulnak elő a megadott nemnegatív egész számban!
    /// A tömb 0. eleme a 0 számjegy, az 1. eleme az 1 számjegy gyakorisága stb.
    /// Példa: 2025512 -> [1, 1, 2, 0, 0, 2, 0, 0, 0, 0].
    /// Gondolj arra az esetre is, amikor maga a szám 0.
    /// </summary>
    public static int[] SzamjegyGyakorisag(int szam)
    {
        return Array.Empty<int>();
    }

    /// <summary>
    /// 9. feladat – Legnagyobb különbség két szomszédos elem között
    /// Számítsd ki minden két egymás mellett álló tömbelem abszolút különbségét,
    /// majd add vissza ezek közül a legnagyobbat!
    /// Példa: [12, 15, 8, 20, 18] -> 12.
    /// A szomszédos különbségek: 3, 7, 12 és 2.
    /// Gondolj két elemű, azonos elemekből álló és negatív számokat tartalmazó tömbökre is.
    /// </summary>
    public static int LegnagyobbSzomszedKulonbseg(int[] szamok)
    {
        return -1;
    }

    // =========================
    // NEHÉZ FELADATOK
    // =========================

    /// <summary>
    /// 10. feladat – Legnagyobb összegű 2x2-es terület
    /// A metódus egy legalább 2x2 méretű egész számmátrixot kap.
    /// Vizsgáld meg a mátrix összes összefüggő 2x2-es területét!
    /// Egy ilyen terület két szomszédos sor és két szomszédos oszlop metszetéből áll.
    /// Számítsd ki minden 2x2-es terület négy elemének összegét,
    /// majd add vissza a legnagyobb ilyen összeget!
    ///
    /// Példa:
    /// 2  4  1
    /// 3  8  5
    /// 1  2  6
    ///
    /// A négy lehetséges 2x2-es terület összege: 17, 18, 14 és 21,
    /// ezért az eredmény 21.
    /// Gondolj pontosan 2x2-es, nagyobb és negatív számokat tartalmazó mátrixokra is.
    /// </summary>
    public static int LegnagyobbKetSzerKettoOsszeg(int[,] matrix)
    {
        return 0;
    }
}

