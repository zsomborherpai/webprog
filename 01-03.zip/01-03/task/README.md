# C# gyakorló feladatsor 01-03 – .NET 8

A projekt **10 fokozatosan nehezedő feladatot** tartalmaz: 5 könnyű, 4 közepes és 1 nehéz feladatot. A feladatok a korábban tanult metódusokra, alapalgoritmusokra, string- és számjegyfeldolgozásra, valamint tömb- és mátrixfeldolgozásra épülnek. A pontozás nem csak a példákra épít: a megoldásoknak a szélső, de a feladat szempontjából értelmes esetekre is helyes eredményt kell adniuk.

## Használat

A megoldandó metódusok a `Feladatok.cs` fájlban találhatók. Minden metódus fölött rövid XML `summary` tartalmazza a feladat lényegét. A metódusok törzse szándékosan nincs elkészítve, csak egy ideiglenes `return` található bennük.

```bash
dotnet run
```

> A feladatok megoldásakor a `Feladatok.cs` fájlban dolgozz. A `Program.cs` tesztjeit ne módosítsd.

---

# Könnyű feladatok

## 1. Kisbetűk száma

Add vissza, hány kisbetű található a megadott szövegben. Gondolj az üres szövegre és arra az esetre is, amikor nincs kisbetű.

## 2. Legnagyobb számjegy

Add vissza egy nemnegatív egész szám legnagyobb számjegyét. A `0` esetén az eredmény `0`.

## 3. Páros számok összege

Add össze a tömbben található páros számokat. Ha nincs páros szám, az eredmény `0`. A `0` páros, de az összeghez 0-t ad.

## 4. Utolsó negatív szám értéke

Add vissza a tömbben található utolsó negatív szám értékét. Ha nincs negatív szám, adj vissza `0`-t. Fontos: nem indexet, hanem értéket kell visszaadni.

## 5. Átlag alatti elemek száma

Számítsd ki a tömb elemeinek átlagát, majd add vissza, hány elem kisebb szigorúan az átlagnál. Gondolj az egy elemű és az azonos értékeket tartalmazó tömbre is.

---

# Közepes feladatok

## 6. Jelszó alapellenőrzése

Egy jelszó akkor érvényes, ha legalább 8 karakter hosszú, tartalmaz legalább egy nagybetűt, egy kisbetűt és egy számjegyet.

## 7. Első átlag feletti dolgozó

A dolgozók neve és pontszáma azonos indexen összetartozik. Számítsd ki a pontszámok átlagát, majd add vissza az első olyan dolgozó nevét, akinek pontszáma szigorúan nagyobb az átlagnál.

## 8. Számjegygyakoriság

Készíts egy 10 elemű tömböt, amely megadja, hogy a 0-9 számjegyek hányszor fordulnak elő a megadott nemnegatív egész számban. Gondolj arra az esetre is, amikor maga a szám `0`.

## 9. Legnagyobb különbség két szomszédos elem között

Számítsd ki minden két egymás mellett álló tömbelem abszolút különbségét, majd add vissza ezek közül a legnagyobbat. Gondolj két elemű, azonos elemekből álló és negatív számokat tartalmazó tömbökre is.

---

# Nehéz feladat

## 10. Legnagyobb összegű 2x2-es terület

A metódus egy egész számmátrixot kap. Vizsgáld meg a mátrix összes összefüggő 2x2-es területét, számítsd ki minden ilyen terület négy elemének összegét, majd add vissza a legnagyobb ilyen összeget. Gondolj pontosan 2x2-es, nagyobb és negatív számokat tartalmazó mátrixokra is.
