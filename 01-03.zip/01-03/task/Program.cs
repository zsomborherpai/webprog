using CSharpGyakorloFeladatsor;

Console.WriteLine("01-03 – C# gyakorló feladatsor\n");

Teszt("1. Kisbetűk száma", Feladatok.KisbetukSzama("Almafa12"), 5);
Teszt("2. Legnagyobb számjegy", Feladatok.LegnagyobbSzamjegy(583204), 8);
Teszt("3. Páros számok összege", Feladatok.ParosSzamokOsszege([5, 8, -2, 7, 4]), 10);
Teszt("4. Utolsó negatív szám értéke", Feladatok.UtolsoNegativErtek([4, -7, 8, -3, 5]), -3);
Teszt("5. Átlag alatti elemek száma", Feladatok.AtlagAlattiDarab([10, 20, 30, 40]), 2);
Teszt("6. Jelszó alapellenőrzése", Feladatok.ErvenyesJelszo("Almafa25"), true);
Teszt("7. Első átlag feletti dolgozó", Feladatok.ElsoAtlagFelettiDolgozo(["Anna", "Bela", "Csilla", "David"], [60, 70, 95, 75]), "Csilla");
TesztTomb("8. Számjegygyakoriság", Feladatok.SzamjegyGyakorisag(2025512), [1, 1, 2, 0, 0, 2, 0, 0, 0, 0]);
Teszt("9. Legnagyobb szomszédos különbség", Feladatok.LegnagyobbSzomszedKulonbseg([12, 15, 8, 20, 18]), 12);
Teszt("10. Legnagyobb 2x2 összeg", Feladatok.LegnagyobbKetSzerKettoOsszeg(new int[,] { { 2, 4, 1 }, { 3, 8, 5 }, { 1, 2, 6 } }), 21);

static void Teszt<T>(string nev, T kapott, T vart)
{
    bool jo = EqualityComparer<T>.Default.Equals(kapott, vart);
    Console.WriteLine($"{(jo ? "[OK]" : "[HIBA]")} {nev} | kapott: {kapott} | várt: {vart}");
}

static void TesztTomb(string nev, int[] kapott, int[] vart)
{
    bool jo = kapott.SequenceEqual(vart);
    Console.WriteLine($"{(jo ? "[OK]" : "[HIBA]")} {nev} | kapott: [{string.Join(", ", kapott)}] | várt: [{string.Join(", ", vart)}]");
}
