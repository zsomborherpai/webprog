using System.Reflection;
using TaskChecker.Grading;

internal static class Grader
{
    private const string TaskNamespace = "CSharpGyakorloFeladatsor";
    private const string TaskClassName = "Feladatok";

    public static IReadOnlyList<TaskScore> Grade(Assembly assembly, PilotMode pilotMode)
    {
        return
        [
            GradeKisbetukSzama(assembly, pilotMode),
            GradeLegnagyobbSzamjegy(assembly, pilotMode),
            GradeParosSzamokOsszege(assembly, pilotMode),
            GradeUtolsoNegativErtek(assembly, pilotMode),
            GradeAtlagAlattiDarab(assembly, pilotMode),
            GradeErvenyesJelszo(assembly, pilotMode),
            GradeElsoAtlagFelettiDolgozo(assembly, pilotMode),
            GradeSzamjegyGyakorisag(assembly, pilotMode),
            GradeLegnagyobbSzomszedKulonbseg(assembly, pilotMode),
            GradeLegnagyobbKetSzerKettoOsszeg(assembly, pilotMode)
        ];
    }

    private static TaskScore GradeKisbetukSzama(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.lowercase-count", "Kisbetuk szama", 8)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<int>(
                "KisbetukSzama",
                0,
                "Megvan a public static int KisbetukSzama(string szoveg) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.lowercase-count.signature", ["method.signature", "string"], "KisbetukSzama signature", 0),
                typeof(string))
            .MethodReturnsForEachCase(
                "KisbetukSzama",
                [
                    MethodCase.Args("Almafa12").Returns(5),
                    MethodCase.Args("").Returns(0),
                    MethodCase.Args("ABC123!").Returns(0),
                    MethodCase.Args("abc").Returns(3),
                    MethodCase.Args("aB cD!").Returns(2)
                ],
                8,
                "A KisbetukSzama helyesen szamolja a kisbetuket.",
                Diagnostics(pilotMode, "array-methods.01-03.lowercase-count.behavior", ["string.traversal", "char.check"], "Kisbetuk szamlalasa", 8),
                typeof(string))
            .Build();
    }

    private static TaskScore GradeLegnagyobbSzamjegy(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.max-digit", "Legnagyobb szamjegy", 8)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.max-digit.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<int>(
                "LegnagyobbSzamjegy",
                0,
                "Megvan a public static int LegnagyobbSzamjegy(int szam) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.max-digit.signature", ["method.signature", "number"], "LegnagyobbSzamjegy signature", 0),
                typeof(int))
            .MethodReturnsForEachCase(
                "LegnagyobbSzamjegy",
                [
                    MethodCase.Args(583204).Returns(8),
                    MethodCase.Args(0).Returns(0),
                    MethodCase.Args(7).Returns(7),
                    MethodCase.Args(1002003).Returns(3),
                    MethodCase.Args(987654321).Returns(9)
                ],
                8,
                "A LegnagyobbSzamjegy helyesen keresi a legnagyobb szamjegyet.",
                Diagnostics(pilotMode, "array-methods.01-03.max-digit.behavior", ["number.digits", "maximum-search"], "Legnagyobb szamjegy", 8),
                typeof(int))
            .Build();
    }

    private static TaskScore GradeParosSzamokOsszege(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.even-number-sum", "Paros szamok osszege", 8)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.even-number-sum.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<int>(
                "ParosSzamokOsszege",
                0,
                "Megvan a public static int ParosSzamokOsszege(int[] szamok) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.even-number-sum.signature", ["method.signature", "array"], "ParosSzamokOsszege signature", 0),
                typeof(int[]))
            .MethodReturnsForEachCase(
                "ParosSzamokOsszege",
                [
                    MethodCase.Args(new[] { 5, 8, -2, 7, 4 }).Returns(10),
                    MethodCase.Args(Array.Empty<int>()).Returns(0),
                    MethodCase.Args(new[] { 1, 3, 5 }).Returns(0),
                    MethodCase.Args(new[] { 2, 4, 6 }).Returns(12),
                    MethodCase.Args(new[] { -4, -3, 0, 8 }).Returns(4)
                ],
                8,
                "A ParosSzamokOsszege helyesen osszegzi a paros elemeket.",
                Diagnostics(pilotMode, "array-methods.01-03.even-number-sum.behavior", ["array.traversal", "conditional-sum"], "Paros szamok osszege", 8),
                typeof(int[]))
            .Build();
    }

    private static TaskScore GradeUtolsoNegativErtek(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.last-negative-value", "Utolso negativ ertek", 8)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.last-negative-value.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<int>(
                "UtolsoNegativErtek",
                0,
                "Megvan a public static int UtolsoNegativErtek(int[] szamok) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.last-negative-value.signature", ["method.signature", "array"], "UtolsoNegativErtek signature", 0),
                typeof(int[]))
            .MethodReturnsForCases(
                "UtolsoNegativErtek",
                [
                    MethodCase.Args(new[] { 4, -7, 8, -3, 5 }).Returns(-3),
                    MethodCase.Args(Array.Empty<int>()).Returns(0),
                    MethodCase.Args(new[] { 1, 2, 3 }).Returns(0),
                    MethodCase.Args(new[] { -1, -2, -3 }).Returns(-3),
                    MethodCase.Args(new[] { -5, 0, 2 }).Returns(-5)
                ],
                8,
                "Az UtolsoNegativErtek csak akkor kap pontot, ha minden esetben helyes erteket ad vissza.",
                Diagnostics(pilotMode, "array-methods.01-03.last-negative-value.behavior", ["array.search", "condition"], "Utolso negativ ertek", 8),
                typeof(int[]))
            .Build();
    }

    private static TaskScore GradeAtlagAlattiDarab(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.below-average-count", "Atlag alatti darab", 10)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.below-average-count.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<int>(
                "AtlagAlattiDarab",
                0,
                "Megvan a public static int AtlagAlattiDarab(int[] szamok) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.below-average-count.signature", ["method.signature", "array"], "AtlagAlattiDarab signature", 0),
                typeof(int[]))
            .MethodReturnsForEachCase(
                "AtlagAlattiDarab",
                [
                    MethodCase.Args(new[] { 10, 20, 30, 40 }).Returns(2),
                    MethodCase.Args(new[] { 5 }).Returns(0),
                    MethodCase.Args(new[] { 7, 7, 7 }).Returns(0),
                    MethodCase.Args(new[] { 1, 2, 100 }).Returns(2),
                    MethodCase.Args(new[] { -10, 0, 10 }).Returns(1)
                ],
                10,
                "Az AtlagAlattiDarab helyesen szamolja az atlag alatti elemeket.",
                Diagnostics(pilotMode, "array-methods.01-03.below-average-count.behavior", ["array.average", "counting"], "Atlag alatti elemek szama", 10),
                typeof(int[]))
            .Build();
    }

    private static TaskScore GradeErvenyesJelszo(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.password-validation", "Ervenyes jelszo", 10)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.password-validation.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<bool>(
                "ErvenyesJelszo",
                0,
                "Megvan a public static bool ErvenyesJelszo(string jelszo) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.password-validation.signature", ["method.signature", "string.validation"], "ErvenyesJelszo signature", 0),
                typeof(string))
            .MethodReturnsForCases(
                "ErvenyesJelszo",
                [
                    MethodCase.Args("Almafa25").Returns(true),
                    MethodCase.Args("Jelszo123").Returns(true),
                    MethodCase.Args("Aa1aaaaa").Returns(true),
                    MethodCase.Args("almafa25").Returns(false),
                    MethodCase.Args("ALMAFA25").Returns(false),
                    MethodCase.Args("Almafaaa").Returns(false),
                    MethodCase.Args("Aa1").Returns(false),
                    MethodCase.Args("12345678").Returns(false)
                ],
                10,
                "Az ErvenyesJelszo csak akkor kap pontot, ha minden ervenyes es ervenytelen jelszot helyesen ellenoriz.",
                Diagnostics(pilotMode, "array-methods.01-03.password-validation.behavior", ["string.validation", "char.check"], "Jelszo validacio", 10),
                typeof(string))
            .Build();
    }

    private static TaskScore GradeElsoAtlagFelettiDolgozo(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.first-above-average-worker", "Elso atlag feletti dolgozo", 10)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.first-above-average-worker.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<string>(
                "ElsoAtlagFelettiDolgozo",
                0,
                "Megvan a public static string ElsoAtlagFelettiDolgozo(string[] nevek, int[] pontok) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.first-above-average-worker.signature", ["method.signature", "parallel-arrays"], "ElsoAtlagFelettiDolgozo signature", 0),
                typeof(string[]), typeof(int[]))
            .MethodReturnsForEachCase(
                "ElsoAtlagFelettiDolgozo",
                [
                    MethodCase.Args(new[] { "Anna", "Bela", "Csilla", "David" }, new[] { 60, 70, 95, 75 }).Returns("Csilla"),
                    MethodCase.Args(new[] { "A", "B" }, new[] { 1, 3 }).Returns("B"),
                    MethodCase.Args(new[] { "A", "B", "C" }, new[] { 10, 30, 20 }).Returns("B"),
                    MethodCase.Args(new[] { "A", "B", "C" }, new[] { 5, 5, 8 }).Returns("C"),
                    MethodCase.Args(new[] { "A", "B", "C", "D" }, new[] { 10, 20, 20, 40 }).Returns("D")
                ],
                10,
                "Az ElsoAtlagFelettiDolgozo helyesen adja vissza az elso atlag feletti dolgozot.",
                Diagnostics(pilotMode, "array-methods.01-03.first-above-average-worker.behavior", ["parallel-arrays", "average"], "Elso atlag feletti dolgozo", 10),
                typeof(string[]), typeof(int[]))
            .Build();
    }

    private static TaskScore GradeSzamjegyGyakorisag(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.digit-frequency", "Szamjegy gyakorisag", 10)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.digit-frequency.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<int[]>(
                "SzamjegyGyakorisag",
                0,
                "Megvan a public static int[] SzamjegyGyakorisag(int szam) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.digit-frequency.signature", ["method.signature", "number"], "SzamjegyGyakorisag signature", 0),
                typeof(int))
            .MethodReturnsForEachCase(
                "SzamjegyGyakorisag",
                [
                    MethodCase.Args(2025512).Returns(new[] { 1, 1, 2, 0, 0, 2, 0, 0, 0, 0 }),
                    MethodCase.Args(0).Returns(new[] { 1, 0, 0, 0, 0, 0, 0, 0, 0, 0 }),
                    MethodCase.Args(11111).Returns(new[] { 0, 5, 0, 0, 0, 0, 0, 0, 0, 0 }),
                    MethodCase.Args(987654321).Returns(new[] { 0, 1, 1, 1, 1, 1, 1, 1, 1, 1 }),
                    MethodCase.Args(1002003).Returns(new[] { 4, 1, 1, 2, 0, 0, 0, 0, 0, 0 })
                ],
                10,
                "A SzamjegyGyakorisag helyes gyakorisagi tombot keszit.",
                Diagnostics(pilotMode, "array-methods.01-03.digit-frequency.behavior", ["number.digits", "histogram"], "Szamjegy gyakorisag", 10),
                typeof(int))
            .Build();
    }

    private static TaskScore GradeLegnagyobbSzomszedKulonbseg(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.max-neighbor-difference", "Legnagyobb szomszed kulonbseg", 12)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.max-neighbor-difference.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<int>(
                "LegnagyobbSzomszedKulonbseg",
                0,
                "Megvan a public static int LegnagyobbSzomszedKulonbseg(int[] szamok) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.max-neighbor-difference.signature", ["method.signature", "array"], "LegnagyobbSzomszedKulonbseg signature", 0),
                typeof(int[]))
            .MethodReturnsForEachCase(
                "LegnagyobbSzomszedKulonbseg",
                [
                    MethodCase.Args(new[] { 12, 15, 8, 20, 18 }).Returns(12),
                    MethodCase.Args(new[] { 1, 2 }).Returns(1),
                    MethodCase.Args(new[] { 5, 5, 5 }).Returns(0),
                    MethodCase.Args(new[] { -10, 10, -5 }).Returns(20),
                    MethodCase.Args(new[] { 100, 50, 0, -50 }).Returns(50)
                ],
                12,
                "A LegnagyobbSzomszedKulonbseg helyesen keresi a legnagyobb abszolut szomszedos kulonbseget.",
                Diagnostics(pilotMode, "array-methods.01-03.max-neighbor-difference.behavior", ["array.traversal", "difference"], "Legnagyobb szomszed kulonbseg", 12),
                typeof(int[]))
            .Build();
    }

    private static TaskScore GradeLegnagyobbKetSzerKettoOsszeg(Assembly assembly, PilotMode pilotMode)
    {
        return ForTask(assembly, "array-methods.01-03.max-2x2-sum", "Legnagyobb 2x2 osszeg", 16)
            .HasPublicStaticClass(0, "A Feladatok osztaly public static class.", Diagnostics(pilotMode, "array-methods.01-03.max-2x2-sum.class.static", ["static-class"], "Feladatok public static class", 0))
            .HasPublicStaticMethod<int>(
                "LegnagyobbKetSzerKettoOsszeg",
                0,
                "Megvan a public static int LegnagyobbKetSzerKettoOsszeg(int[,] matrix) metodus.",
                Diagnostics(pilotMode, "array-methods.01-03.max-2x2-sum.signature", ["method.signature", "matrix"], "LegnagyobbKetSzerKettoOsszeg signature", 0),
                typeof(int[,]))
            .MethodReturnsForEachCase(
                "LegnagyobbKetSzerKettoOsszeg",
                [
                    MethodCase.Args(new int[,] { { 2, 4, 1 }, { 3, 8, 5 }, { 1, 2, 6 } }).Returns(21),
                    MethodCase.Args(new int[,] { { 1, 2 }, { 3, 4 } }).Returns(10),
                    MethodCase.Args(new int[,] { { -5, -1 }, { -2, -2 } }).Returns(-10),
                    MethodCase.Args(new int[,] { { 1, 1, 1 }, { 1, 9, 1 } }).Returns(12),
                    MethodCase.Args(new int[,] { { 5, 0, 1 }, { 2, 3, 4 }, { 1, 1, 10 } }).Returns(18)
                ],
                16,
                "A LegnagyobbKetSzerKettoOsszeg helyesen keresi a legnagyobb 2x2-es terulet osszeget.",
                Diagnostics(pilotMode, "array-methods.01-03.max-2x2-sum.behavior", ["matrix", "maximum-search"], "Legnagyobb 2x2 osszeg", 16),
                typeof(int[,]))
            .Build();
    }

    private static ReflectionStaticClassGrader ForTask(
        Assembly assembly,
        string taskId,
        string title,
        decimal maxPoints)
    {
        return ReflectionStaticClassGrader.ForTask(assembly, TaskNamespace, TaskClassName, taskId, title, maxPoints);
    }

    private static CheckDiagnostics? Diagnostics(
        PilotMode pilotMode,
        string checkId,
        IReadOnlyList<string> learningOutcomeIds,
        string title,
        decimal weight)
    {
        if (pilotMode == PilotMode.Basic110)
            return null;

        return CheckDiagnostics.For(checkId, learningOutcomeIds, title, weight);
    }
}
